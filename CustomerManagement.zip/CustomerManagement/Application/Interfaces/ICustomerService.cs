﻿using System.Collections.Generic;

namespace Customer.Services
{
    public interface ICustomerService
    {
        List<CustomerEntity> Get();
        List<CustomerEntity> GetById(int id);
    }
}
