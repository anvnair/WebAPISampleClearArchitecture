﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Customer.Services
{
    public class CustomerEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
