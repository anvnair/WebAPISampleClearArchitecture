﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Customer.Services
{
    public class UnitOfWork : IUnitOfWork
    {
        CustomerContext _context;
        BaseRepository<CustomerEntity> customers;
        public UnitOfWork(CustomerContext context)
        {
            _context = context;
        }
        public IRepository<CustomerEntity> Customers
        {
            get => customers ?? new BaseRepository<CustomerEntity>(_context);
        }

        public int Save(int InitiatedAppId)
        {
            try
            {
                if (InitiatedAppId == 0)
                    throw new DivideByZeroException("error");

                return _context.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
