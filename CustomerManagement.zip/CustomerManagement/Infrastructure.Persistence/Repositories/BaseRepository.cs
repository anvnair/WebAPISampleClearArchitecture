﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Customer.Services
{
    public class BaseRepository<T> : IRepository<T> where T : class
    {
        private readonly CustomerContext _cusContext;
        internal DbSet<T> dbSet;
        public BaseRepository(CustomerContext cusContext)
        {
            _cusContext = cusContext;
            this.dbSet = cusContext.Set<T>();
        }
        public virtual void Create(T newRecord)
        {
            this.dbSet.Add(newRecord);
        }

        public virtual IEnumerable<T> Read()
        {
            return dbSet.AsEnumerable<T>();
        }

        public virtual void Update(T recordtoUpdate)
        {
            throw new NotImplementedException();
        }
    }
}
