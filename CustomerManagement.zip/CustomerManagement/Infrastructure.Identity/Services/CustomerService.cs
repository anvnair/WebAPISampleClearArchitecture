﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Customer.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly CustomerContext _context;
        UnitOfWork _unitOfWork;

        public CustomerService(CustomerContext context)
        {
            _context = context;
            _unitOfWork = new UnitOfWork(context);
        }
        public List<CustomerEntity> Get()
        {
            return _unitOfWork.Customers.Read().ToList();
        }
        public List<CustomerEntity> GetById(int id)
        {
            if (id == 0) throw new DivideByZeroException();
            return _unitOfWork.Customers.Read().ToList();
        }
    }
}
