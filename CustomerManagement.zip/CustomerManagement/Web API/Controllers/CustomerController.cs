﻿using Customer.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace Web_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ILogger<CustomerController> _logger;
        private readonly CustomerContext _context;
        private readonly ICustomerService _customerService;

        public CustomerController(ILogger<CustomerController> logger, CustomerContext context, ICustomerService customerService)
        {
            _logger = logger;
            _context = context;
            _customerService = customerService;
        }

        [HttpGet]
        public List<CustomerEntity> GetAllCustomers()
        {

            return _customerService.Get();
        }
    }
}
