﻿using Microsoft.EntityFrameworkCore;

namespace Customer.Services
{
    public class CustomerContext : DbContext
    {
        public CustomerContext(DbContextOptions<CustomerContext> options) : base(options)
        {
        }
        public DbSet<CustomerEntity> Customers { get; set; }
    }
}
